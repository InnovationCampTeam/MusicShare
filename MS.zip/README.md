"# MusicShare" 
* https://leather-pixie-4bc.notion.site/2024-NE-Innovation-Camp-14-ac02e28f97144d15a099c4cedd3694ed
